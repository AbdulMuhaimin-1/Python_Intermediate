class NotificationManager:
    #This class is responsible for sending notifications with the deal flight details.
    pass